﻿using System;

namespace Exee4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, cont = 0,i,ii;

            Console.WriteLine("Digite um numero abaixo");
            num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite mais um numero abaixo, e o programa exibira se a quantidade de numeros impares digitados.");
            num2 = int.Parse(Console.ReadLine());

            int menor = Math.Min(num1, num2); //depois de não conseguir fazer o exercicio do zero e não entender tão bem pedi ajuda ao gpt
                                              //OBS: EU JURO QUE NÃO COPIEI CÓDIGO a unica coisa que eu realmente pedi algo usar o gpt foi um norte do funcionamento
                                              //do exércicio, ou seja não copiei o código todo só pedi pra explicar oque eu deveria fazer, sem isso eu ia usar só If ;--;
                                              //importante mencionar que usei Math.min e max por que pesquisei um comando que definia minímo e maxímo e só consegui fazer
                                              //usando os mesmos, espero compreensão mas caso seja necessário aceitarei qualquer decrecimo na pontuação total que esse 
                                              //exércicio vale na minha nota total ou afins,e também Agradeço o tempo que gastaram lendo esse textão :)
            int maior = Math.Max(num1, num2);

            for (ii = num1 + 1; ii < num2; ii++)
            {
                if (ii % 2 != 0)
                {
                    cont++;
                }
                if (num2 % 2 != 0)
                {
                    cont++;
                }
                if (num1 % 2 != 0)
                {
                    cont++;
                }
            }
            Console.WriteLine("A quantidade de números ímpares entre " + menor + " e " + maior + " é: " + cont );

        }
    }
}
