﻿using System;

namespace Exee1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = 11;
            Console.WriteLine("Estes são todos os números pares de 11 a 250");
            do {
               if (num % 2 == 0)
                { 
                    Console.WriteLine(num);
            }
                num++;
            }
            while (num <= 250);

        }
    }
}

