﻿using System;

namespace Exee2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num,num1;
            Console.WriteLine("Digite dois numeros sendo que um deles iniciara e o outro terminara uma sequencia decresente ou seja obrigatoriamente o primeiro deve ser maior que o segundo!!");
            num =  Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite agora o numero no qual a sequencia termina ou o menor numero");
            num1 = Convert.ToInt32(Console.ReadLine());
            while (num1 < num)
            {
                Console.WriteLine(num);
                num--;
            }

        }
    }
}
