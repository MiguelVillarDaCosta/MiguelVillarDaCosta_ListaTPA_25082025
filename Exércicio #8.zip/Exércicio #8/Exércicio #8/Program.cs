﻿using System;

namespace Exee8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a,b,c,d,e,f,g = 1,h,i,j;
            Console.WriteLine("Digite um numero e o computador calculara o seu fatorial");
             c = int.Parse(Console.ReadLine());
            do
            {
                Console.WriteLine(c * g++);
            } while (g <= c );
            }
        }
    }