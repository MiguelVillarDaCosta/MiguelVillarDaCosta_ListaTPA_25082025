﻿using System;

namespace Exee7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um número: ");
            int l = int.Parse(Console.ReadLine());

            if (l > 100)
            {
                l = 100;
            }

            for (int i = 10; i <= l; i += 10)
            {
                Console.WriteLine("MULTIPLOS DE 10");
            }
            Console.WriteLine("se voce for um besta sem tempo e ou trabalho e ");
            Console.WriteLine("tentar passar do numero 100 so vão ser exibidos");
            Console.WriteLine("os multiplos de 10 como se o seu numero fosse 100");
            Console.ReadKey();
        }
    }
}
