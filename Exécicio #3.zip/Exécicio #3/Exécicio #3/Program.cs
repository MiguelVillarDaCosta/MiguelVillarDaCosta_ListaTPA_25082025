﻿using System;

namespace Exee3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2 = 1 , num3 ;
            Console.WriteLine("digite um numnero para que o programa faca uma tabuada do mesmo que va de 1 a 10");  
            num1 = int.Parse(Console.ReadLine());
            do {

                num3 = num1 * num2 ;
                Console.WriteLine( num1 + " x " + num2 + " = " + num3);               
                num2++;   
            }while (num2 <= 10);
        }
    }
}